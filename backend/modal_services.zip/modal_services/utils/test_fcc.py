"""
test_endpoint.py

Test the deployed Modal web endpoint with a base64 image.

Usage:
    python test_endpoint.py [input_image_path]
    
If no image is provided, creates a synthetic test image.
"""

import base64
import json
import sys
import requests
from io import BytesIO

# Modal endpoint URL
ENDPOINT_URL = "https://rockstar4119--fcc-rgb-synthesis-process-fcc-image.modal.run"


def create_test_image():
    """Create a simple synthetic 3-channel test image."""
    try:
        from PIL import Image
        import numpy as np
        
        # Create a 256x256 synthetic FCC-like image (3 channels)
        np.random.seed(42)
        
        # Simulate NIR, R, G channels with some structure
        h, w = 256, 256
        
        # Create gradient + noise pattern
        x = np.linspace(0, 1, w)
        y = np.linspace(0, 1, h)
        xx, yy = np.meshgrid(x, y)
        
        ch1 = (xx * 0.7 + np.random.rand(h, w) * 0.3) * 255  # NIR-like
        ch2 = (yy * 0.6 + np.random.rand(h, w) * 0.4) * 255  # R-like  
        ch3 = ((xx + yy) / 2 * 0.5 + np.random.rand(h, w) * 0.5) * 255  # G-like
        
        img_array = np.stack([ch1, ch2, ch3], axis=-1).astype(np.uint8)
        img = Image.fromarray(img_array, mode='RGB')
        
        # Save locally for reference
        img.save("test_input.png")
        print("Created synthetic test image: test_input.png")
        
        return img
        
    except ImportError:
        print("PIL/numpy not installed. Please provide an image path.")
        sys.exit(1)


def image_to_base64(image_path=None, pil_image=None):
    """Convert image to base64 string."""
    from PIL import Image
    
    if pil_image:
        img = pil_image
    elif image_path:
        img = Image.open(image_path)
    else:
        raise ValueError("Provide either image_path or pil_image")
    
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def test_endpoint(image_base64: str):
    """Send image to endpoint and get response."""
    
    print(f"\nSending request to: {ENDPOINT_URL}")
    print(f"Image base64 length: {len(image_base64)} chars")
    
    payload = {
        "image_base64": image_base64,
        "return_band_info": True
    }
    
    try:
        response = requests.post(
            ENDPOINT_URL,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=120  # 2 minute timeout for cold start
        )
        
        print(f"Response status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            
            if "error" in result:
                print(f"❌ Error from endpoint: {result['error']}")
                return None
            
            if "image_base64" in result:
                # Decode and save output image
                output_bytes = base64.b64decode(result["image_base64"])
                output_path = "test_output.png"
                
                with open(output_path, "wb") as f:
                    f.write(output_bytes)
                
                print(f"✓ Output image saved to: {output_path}")
                print(f"  Output size: {len(output_bytes) / 1024:.1f} KB")
                
                # Print band info if available
                if "band_info" in result and result["band_info"]:
                    band_info = result["band_info"]
                    print("\nBand prediction info:")
                    print(f"  Predicted bands (raw): {band_info.get('predicted_bands_raw', 'N/A')}")
                    print(f"  Predicted bands (repaired): {band_info.get('predicted_bands_repaired', 'N/A')}")
                    print(f"  Synthesized channel: {band_info.get('synthesized_channel', 'None')}")
                
                return result
            else:
                print(f"❌ Unexpected response: {result}")
                return None
        else:
            print(f"❌ Request failed: {response.text}")
            return None
            
    except requests.exceptions.Timeout:
        print("❌ Request timed out (cold start may take longer)")
        return None
    except Exception as e:
        print(f"❌ Request error: {e}")
        return None


def main():
    # Check if image path provided
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        print(f"Using provided image: {image_path}")
        image_base64 = image_to_base64(image_path=image_path)
    else:
        print("No image provided, creating synthetic test image...")
        test_img = create_test_image()
        image_base64 = image_to_base64(pil_image=test_img)
    
    # Test the endpoint
    result = test_endpoint(image_base64)
    
    if result:
        print("\n✓ Endpoint test successful!")
    else:
        print("\n❌ Endpoint test failed")


if __name__ == "__main__":
    main()
