"""
modal_app.py

Modal deployment for FCC to RGB synthesis pipeline.
Uses Modal Volume for persistent model storage.

Setup:
1. Create the volume and upload models:
   modal volume create fcc-models
   modal volume put fcc-models best_model.pth /best_model.pth
   modal volume put fcc-models models_ir_rgb.npz /models_ir_rgb.npz

2. Deploy the app:
   modal deploy modal_app.py

3. Or run locally for testing:
   modal run modal_app.py
"""

import modal

# =============================================================================
# MODAL CONFIGURATION
# =============================================================================

APP_NAME = "fcc-rgb-synthesis"
VOLUME_NAME = "fcc-models"
MODELS_MOUNT_PATH = "/models"

# Model file paths (inside the mounted volume)
SPECTRAL_MODEL_PATH = f"{MODELS_MOUNT_PATH}/best_model.pth"
IR2RGB_MODEL_PATH = f"{MODELS_MOUNT_PATH}/models_ir_rgb.npz"

# Create Modal app and volume
app = modal.App(APP_NAME)
model_volume = modal.Volume.from_name(VOLUME_NAME, create_if_missing=True)

# Define container image with required dependencies
image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "torch",
        "torchvision", 
        "numpy",
        "opencv-python-headless",
        "pillow",
        "fastapi[standard]",
    )
    .add_local_file("unified_spectral_synthesis.py", "/app/unified_spectral_synthesis.py")
)


# =============================================================================
# MODEL UPLOAD UTILITY
# =============================================================================

@app.function(
    volumes={MODELS_MOUNT_PATH: model_volume},
    image=modal.Image.debian_slim(),
)
def upload_models(spectral_model_bytes: bytes, ir2rgb_model_bytes: bytes):
    """
    Upload model files to the Modal volume.
    
    Call this once to populate the volume with your trained models.
    
    Example usage from Python:
        with open("best_model.pth", "rb") as f:
            spectral_bytes = f.read()
        with open("models_ir_rgb.npz", "rb") as f:
            ir2rgb_bytes = f.read()
        
        with app.run():
            upload_models.remote(spectral_bytes, ir2rgb_bytes)
    """
    # Write spectral model
    with open(SPECTRAL_MODEL_PATH, "wb") as f:
        f.write(spectral_model_bytes)
    
    # Write IR2RGB model
    with open(IR2RGB_MODEL_PATH, "wb") as f:
        f.write(ir2rgb_model_bytes)
    
    model_volume.commit()
    
    return {"status": "success", "message": "Models uploaded to volume"}


@app.function(
    volumes={MODELS_MOUNT_PATH: model_volume},
    image=modal.Image.debian_slim(),
)
def check_models():
    """Check if model files exist in the volume."""
    import os
    
    results = {}
    for name, path in [
        ("spectral_model", SPECTRAL_MODEL_PATH),
        ("ir2rgb_model", IR2RGB_MODEL_PATH),
    ]:
        exists = os.path.exists(path)
        size = os.path.getsize(path) if exists else 0
        results[name] = {
            "path": path,
            "exists": exists,
            "size_bytes": size,
            "size_mb": round(size / (1024 * 1024), 2) if size > 0 else 0,
        }
    
    return results


# =============================================================================
# FCC PROCESSOR CLASS
# =============================================================================

@app.cls(
    image=image,
    volumes={MODELS_MOUNT_PATH: model_volume},
    scaledown_window=300,  # Keep warm for 5 minutes
)
class FCCProcessor:
    """
    Modal class for FCC to RGB image processing.
    
    Models are loaded once when the container starts via @modal.enter().
    Subsequent requests reuse the loaded models for fast inference.
    """
    
    @modal.enter()
    def load_models(self):
        """Load models from volume into memory (called once on container start)."""
        import sys
        sys.path.insert(0, "/app")
        
        from unified_spectral_synthesis import FCCtoRGBPipeline
        
        print(f"Loading spectral model from: {SPECTRAL_MODEL_PATH}")
        print(f"Loading IR2RGB model from: {IR2RGB_MODEL_PATH}")
        
        self.pipeline = FCCtoRGBPipeline(
            spectral_model_path=SPECTRAL_MODEL_PATH,
            ir2rgb_npz_path=IR2RGB_MODEL_PATH,
            device="cpu",
            resize=True,
            image_size=(1024, 1024),
        )
        
        print("Models loaded successfully!")
    
    @modal.method()
    def process_image(self, image_bytes: bytes, return_band_info: bool = False) -> dict:
        """
        Process an FCC image and return synthesized RGB.
        
        Args:
            image_bytes: Input image as bytes (PNG, JPEG, TIFF, etc.)
            return_band_info: If True, include band prediction details in response.
        
        Returns:
            dict with keys:
                - "image_bytes": Output RGB image as PNG bytes
                - "band_info": (optional) Band prediction metadata
        """
        import io
        import tempfile
        from PIL import Image
        
        # Save input to temp file (pipeline expects file path)
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp.write(image_bytes)
            tmp_path = tmp.name
        
        try:
            # Process image
            if return_band_info:
                result_image, band_info = self.pipeline.process_image(
                    tmp_path, return_band_info=True
                )
            else:
                result_image = self.pipeline.process_image(tmp_path)
                band_info = None
            
            # Convert result to bytes
            output_buffer = io.BytesIO()
            result_image.save(output_buffer, format="PNG")
            output_bytes = output_buffer.getvalue()
            
            response = {"image_bytes": output_bytes}
            if band_info:
                response["band_info"] = band_info
            
            return response
            
        finally:
            # Cleanup temp file
            import os
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    
    @modal.method()
    def health_check(self) -> dict:
        """Check if the processor is ready."""
        return {
            "status": "healthy",
            "pipeline_loaded": hasattr(self, "pipeline") and self.pipeline is not None,
        }


# =============================================================================
# WEB ENDPOINT WITH PROPER INITIALIZATION
# =============================================================================

@app.cls(
    image=image,
    volumes={MODELS_MOUNT_PATH: model_volume},
    scaledown_window=300,
)
class Inference:
    """
    Inference endpoint class with proper model initialization.
    
    Models are loaded once when the container starts via @modal.enter().
    The web endpoint reuses the loaded models for fast inference.
    """
    
    @modal.enter()
    def init(self):
        """Initialize models once when container starts."""
        import sys
        sys.path.insert(0, "/app")
        
        from unified_spectral_synthesis import FCCtoRGBPipeline
        
        print(f"Initializing Inference endpoint...")
        print(f"Loading spectral model from: {SPECTRAL_MODEL_PATH}")
        print(f"Loading IR2RGB model from: {IR2RGB_MODEL_PATH}")
        
        self.pipeline = FCCtoRGBPipeline(
            spectral_model_path=SPECTRAL_MODEL_PATH,
            ir2rgb_npz_path=IR2RGB_MODEL_PATH,
            device="cpu",
            resize=True,
            image_size=(1024, 1024),
        )
        
        print("Inference endpoint initialized successfully!")
    
    @modal.fastapi_endpoint(method="POST")
    def predict(self, request: dict):
        """
        HTTP POST endpoint for FCC image processing.
        
        Expects JSON body with:
            - "image_base64": Base64-encoded input image
            - "return_band_info": (optional) Boolean to include band predictions
        
        Returns JSON with:
            - "image_base64": Base64-encoded output RGB image
            - "band_info": (optional) Band prediction metadata
        """
        import base64
        import io
        import os
        import tempfile
        
        image_base64 = request.get("image_base64")
        if not image_base64:
            return {"error": "Missing 'image_base64' in request body"}
        
        return_band_info = request.get("return_band_info", False)
        
        try:
            image_bytes = base64.b64decode(image_base64)
        except Exception as e:
            return {"error": f"Invalid base64 encoding: {e}"}
        
        # Save to temp file and process
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp.write(image_bytes)
            tmp_path = tmp.name
        
        try:
            if return_band_info:
                result_image, band_info = self.pipeline.process_image(
                    tmp_path, return_band_info=True
                )
            else:
                result_image = self.pipeline.process_image(tmp_path)
                band_info = None
            
            # Encode output
            output_buffer = io.BytesIO()
            result_image.save(output_buffer, format="PNG")
            output_base64 = base64.b64encode(output_buffer.getvalue()).decode("utf-8")
            
            response = {"image_base64": output_base64}
            if band_info:
                response["band_info"] = band_info
            
            return response
            
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    
    @modal.fastapi_endpoint(method="GET")
    def health(self):
        """Health check endpoint."""
        return {
            "status": "healthy",
            "pipeline_loaded": hasattr(self, "pipeline") and self.pipeline is not None,
        }


# =============================================================================
# LOCAL ENTRYPOINT FOR TESTING
# =============================================================================

@app.local_entrypoint()
def main():
    """
    Local entrypoint for testing.
    
    Usage:
        modal run modal_app.py
    """
    print("Checking model files in volume...")
    result = check_models.remote()
    
    for model_name, info in result.items():
        status = "✓" if info["exists"] else "✗"
        print(f"  {status} {model_name}: {info['path']}")
        if info["exists"]:
            print(f"      Size: {info['size_mb']} MB")
    
    all_exist = all(info["exists"] for info in result.values())
    
    if not all_exist:
        print("\n⚠️  Some models are missing! Upload them using:")
        print("    modal volume put fcc-models best_model.pth /best_model.pth")
        print("    modal volume put fcc-models models_ir_rgb.npz /models_ir_rgb.npz")
    else:
        print("\n✓ All models present. Testing processor...")
        processor = FCCProcessor()
        health = processor.health_check.remote()
        print(f"  Health check: {health}")